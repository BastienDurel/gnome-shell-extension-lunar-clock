#ifndef __MOON_DATA_H__
#define __MOON_DATA_H__ 1
/*
 * moondata.h
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * (C) 1999-2004 josh buhl <jbuhl@users.sourceforge.net> 
 *
 */

#include "glunarclock.h"

G_BEGIN_DECLS

gboolean visible(void);
gdouble moonphase(void);
void update_moondata(MoonApplet * moon);
void display_moondata_dialog(MoonApplet * moon);
void update_moondata_dialog(MoonApplet * moon);

G_END_DECLS

#endif				/* !__MOON_DATA_H__ */
